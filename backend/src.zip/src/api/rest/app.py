from fastapi import FastAPI
from fastapi.openapi.utils import get_openapi
from src.api.middleware.cors import register_cors
from src.api.middleware.error_handler import register_exception_handlers
from src.api.middleware.logging import RequestLoggingMiddleware
from src.api.rest.routes.auth import router as auth_router
from src.api.rest.routes.users import router as users_router
from src.api.rest.routes.kyc import kyc_router, kyc_admin_router
from src.api.rest.routes.inventory import router as inventory_router, admin_router as inventory_admin_router

from src.api.rest.routes.bookings import router as bookings_router
from src.api.rest.routes.bookings import admin_router as bookings_admin_router

from src.api.rest.routes.damage import router as damage_router
from src.api.rest.routes.damage import admin_router as damage_admin_router

from src.api.rest.routes.payments import router as payments_router
from src.api.rest.routes.payments import admin_router as payments_admin_router


from src.api.rest.routes.admin import admin_router

from src.api.rest.routes.jobs import admin_router as jobs_admin_router

from src.api.rest.routes.webhooks import webhooks_router

from src.api.rest.routes.health import router as health_router


def create_app() -> FastAPI:
    app = FastAPI(
        title="Car Rental API",
        version="1.0.0",
        openapi_url="/api/openapi.json"
    )

    register_cors(app)
    register_exception_handlers(app)
    app.add_middleware(RequestLoggingMiddleware)

    app.include_router(auth_router, prefix="/auth", tags=["Auth"])
    app.include_router(users_router, prefix="/users", tags=["Users"])
    app.include_router(kyc_router, prefix="/kyc", tags=["KYC"])
    app.include_router(kyc_admin_router, prefix="/admin", tags=["Admin - KYC"])

    app.include_router(inventory_router, prefix="/inventory", tags=["Inventory"])
    app.include_router(inventory_admin_router, prefix="", tags=["Admin - Inventory"])

    app.include_router(bookings_router, prefix="/bookings", tags=["Bookings"])
    app.include_router(bookings_admin_router, prefix="", tags=["Admin - Bookings"])

    app.include_router(damage_router, prefix="", tags=["Damage"])
    app.include_router(damage_admin_router, prefix="", tags=["Admin - Damage"])

    app.include_router(payments_router, prefix="", tags=["Payments"])
    app.include_router(payments_admin_router, prefix="", tags=["Admin - Payments"])

    app.include_router(admin_router, prefix="", tags=["Admin - Users"])

    app.include_router(jobs_admin_router, prefix="", tags=["Admin - Jobs"])

    app.include_router(webhooks_router, prefix="/internal/webhooks", tags=["Internal - Webhooks"])

    app.include_router(health_router)

    # ── Patch OpenAPI schema so Swagger renders vehicle_images as real
    #    file pickers (format:binary) instead of the broken array<string> text box.
    def custom_openapi():
        if app.openapi_schema:
            return app.openapi_schema
        schema = get_openapi(
            title=app.title,
            version=app.version,
            routes=app.routes,
        )
        for schema_name, schema_def in schema.get("components", {}).get("schemas", {}).items():
            props = schema_def.get("properties", {})
            if "vehicle_images" in props:
                props["vehicle_images"] = {
                    "type": "array",
                    "items": {"type": "string", "format": "binary"},
                    "description": "Vehicle photos (JPG/PNG)",
                }
        app.openapi_schema = schema
        return schema


    

    app.openapi = custom_openapi

    return app