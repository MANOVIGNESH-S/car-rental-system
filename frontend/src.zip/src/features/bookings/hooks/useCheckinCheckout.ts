// src/features/bookings/hooks/useCheckinCheckout.ts

import { useState, useCallback } from 'react';
import { 
  checkinBooking, 
  checkoutBooking, 
  type CheckinResponse, 
  type CheckoutResponse 
} from '../services/adminBookingService';
import { uploadPreRentalImages, type DamageUploadFiles } from '../../damage/services/damageService';

export function useCheckinCheckout() {
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [checkinResult, setCheckinResult] = useState<CheckinResponse | null>(null);
  const [checkoutResult, setCheckoutResult] = useState<CheckoutResponse | null>(null);

  const reset = useCallback(() => {
    setIsProcessing(false);
    setError(null);
    setCheckinResult(null);
    setCheckoutResult(null);
  }, []);

  const checkin = useCallback(async (
    bookingId: string, 
    fuelLevel: number, 
    files: DamageUploadFiles
  ): Promise<void> => {
    if (fuelLevel < 0 || fuelLevel > 100) {
      setError('Fuel level must be between 0 and 100.');
      return;
    }

    setIsProcessing(true);
    setError(null);

    try {
      // 1. Upload the pre-rental images first
      await uploadPreRentalImages(bookingId, files);
      
      // 2. If successful, proceed with check-in
      const result = await checkinBooking(bookingId, fuelLevel);
      setCheckinResult(result);
    } catch (err) {
      const e = err as { response?: { data?: { detail?: string } } };
      setError(e.response?.data?.detail || 'Failed to process check-in. Ensure all images are valid.');
    } finally {
      setIsProcessing(false);
    }
  }, []);

  const checkout = useCallback(async (bookingId: string, fuelLevel: number): Promise<void> => {
    // ... (Keep your existing checkout function exactly the same)
    if (fuelLevel < 0 || fuelLevel > 100) {
      setError('Fuel level must be between 0 and 100.');
      return;
    }

    setIsProcessing(true);
    setError(null);

    try {
      const result = await checkoutBooking(bookingId, fuelLevel);
      setCheckoutResult(result);
    } catch (err) {
      const e = err as { response?: { data?: { detail?: string } } };
      setError(e.response?.data?.detail || 'Failed to process check-out.');
    } finally {
      setIsProcessing(false);
    }
  }, []);

  return { checkin, checkout, isProcessing, error, checkinResult, checkoutResult, reset };
}